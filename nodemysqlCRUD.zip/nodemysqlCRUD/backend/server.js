var express = require('express');
const bodyParser = require('body-parser');
const mysql = require("mysql");
var server = express();

const cors = require('cors');


const db = mysql.createConnection({

    host: "localhost",
    user: "root",
    password: "",
    database: "est"
});

db.connect(function(error) {
    if(error) {
        console.log("error");
    }
    else {
        console.log("db connected");
    }
})

server.use(cors());

server.use(express.json());

server.listen(8080,function check(error) {
    if(error) {
        console.log("error");
    }
    else {
        console.log("started!");
    }
});


server.post("/api/employees/add", (req, res) => {
    let details = {
      name: req.body.name,
      address: req.body.address,
      phone: req.body.phone,
    };
    let sql = "INSERT INTO employees SET ?";
    db.query(sql, details, (error) => {
      if (error) {
        res.send({ status: false, message: "employee created Failed" });
      } else {
        res.send({ status: true, message: "employee created successfully" });
      }
    });
  });
//view the Records
server.get("/api/employees", (req, res) => {
    var sql = "SELECT * FROM employees";
    db.query(sql, function (error, result) {
      if (error) {
        console.log("Error Connecting to DB");
      } else {
        res.send({ status: true, data: result });
      }
    });
  });
//Search the Records
server.get("/api/employees/:id", (req, res) => {
    var employeesid = req.params.id;
    var sql = "SELECT * FROM employees WHERE id=" + employeesid;
    db.query(sql, function (error, result) {
      if (error) {
        console.log("Error Connecting to DB");
      } else {
        res.send({ status: true, data: result });
      }
    });
  });
//Update the Records
server.put("/api/employees/update/:id", (req, res) => {
    let sql =
      "UPDATE employees SET name='" +
      req.body.name +
      "', address='" +
      req.body.address +
      "',phone='" +
      req.body.phone +
      "'  WHERE id=" +
      req.params.id;
  
    let a = db.query(sql, (error, result) => {
      if (error) {
        res.send({ status: false, message: "employee Updated Failed" });
      } else {
        res.send({ status: true, message: "employee Updated successfully" });
      }
    });
  });
  //Delete the Records
  server.delete("/api/employees/delete/:id", (req, res) => {
    let sql = "DELETE FROM employees WHERE id=" + req.params.id + "";
    let query = db.query(sql, (error) => {
      if (error) {
        res.send({ status: false, message: "employee Deleted Failed" });
      } else {
        res.send({ status: true, message: "employee Deleted successfully" });
      }
    });
  });
